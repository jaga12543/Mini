# Python Mini Projects For Beginners

I created this repository when I began #100DaysOfCode with Python. I've used Python before, but I had switched to JS related web-dev for a few months, so I wanted to start from scratch. So, I decided to create a repository to add a few small projects I'm doing as a part of the course and probably will add some more projects later.

## How to use this repository?

If you're new to Python, you can take a look at some of the mini projects here to take inspiration and get going. This repository will also help you understand what Python is capable of and all that we can potentially achieve with this language. 

## Contributing

Please read [Contributing.md](/contributing.md) before making a PR.

---
Please star this repository and share with your Python beginner friends :)
