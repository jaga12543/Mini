This is a program that arranges your files according to their extension 
