# This is a program to convert celsius to farenheit using a graphical user interface 

![image](https://user-images.githubusercontent.com/77890735/196344241-cbf5f781-9734-4472-92ad-a32349bfd674.png)


